Second-reader five-target diagnostic, November 8 2026.
Install requirements.txt, then run python -B replay.py --out <new directory outside package>.
All 20 opportunities are retained: 19 saved responses are executed and one original timeout is preserved, not retried. No LLM call occurs. This replays exposed public training cases, not a new benchmark.
The native checker and test worker are unchanged from the earlier public target supplement. User prompt and image bytes match the original comparison, but provider system contexts differ. Source model: claude-opus-5-5. All complete fits and saved-call counts are in SUMMARY.json. Raw model events/reasoning and authentication files are excluded.
The store is frozen. No production learning credit or accuracy advantage follows from this single direct cross-task reuse.
