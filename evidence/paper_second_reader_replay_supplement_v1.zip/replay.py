"""Replay nineteen fixed proposals and preserve the twentieth opportunity as a timeout."""
import argparse,hashlib,json,os,subprocess,sys,time
from pathlib import Path

BASE=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
digest=lambda x:hashlib.sha256(json.dumps(x,sort_keys=True).encode()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')

def verify():
    files=read(BASE/'MANIFEST.json')['files']
    actual={p.relative_to(BASE).as_posix() for p in BASE.rglob('*') if p.is_file() and '__pycache__' not in p.parts}
    assert actual==set(files)|{'MANIFEST.json'}, 'Package file set differs'
    for f,h in files.items():assert sha(BASE/f)==h,f
    return files

def run(out):
    verify();out=Path(out).resolve()
    assert out!=BASE and BASE not in out.parents,'Choose an output directory outside the package'
    out.mkdir(parents=True,exist_ok=False)
    protocol=read(BASE/'STUDY.json'); entries=protocol['entries'];assert len(entries)==20
    environment=dict(os.environ,TRACE_R7=str(BASE/'runtime'),STUDY_REGISTRY='original',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
    all_entries=[]
    for e in entries:
        if not e['available']: continue
        k=e['key'];p=out/k;p.mkdir();meta=read(BASE/e['meta'])
        meta['store_exec']=str(BASE/e['store']);save(p/'meta.json',meta)
        all_entries.append(dict(e,meta=str(p/'meta.json'),out=str(BASE/e['plan_dir']),result=str(p),kind='original'))
    for f in protocol['factored']:
        original=next(e for e in entries if e['key']==f['source_key']);k=f['key'];p=out/k;p.mkdir()
        meta=read(BASE/original['meta']);meta['store_exec']=str(BASE/'store_retained');meta['key']=k
        meta['store_exec_sha256']={n:sha(BASE/'store_retained'/n) for n in ['defs.json','leaves.json','constructs.json']}
        save(p/'meta.json',meta)
        all_entries.append(dict(original,key=k,source_key=f['source_key'],meta=str(p/'meta.json'),out=str(BASE/f['plan_dir']),result=str(p),kind='factored'))
    save(out/'PROTOCOL.json',{'entries':all_entries});(out/'test_inputs').mkdir()
    save(out/'RUN_PROTOCOL.json',{'model_calls':0,'per_process_seconds':180,'total_seconds':1800,'python':sys.version,
        'package_manifest_sha256':sha(BASE/'MANIFEST.json'),'entries':len(all_entries),
        'classification':'Re-execution of fixed plans; not new discovery, held-out evaluation or additional task performance'})
    # The unchanged test worker expects local runtime/study directories. Links are unnecessary:
    # its environment controls the native runtime; only its local study import needs a copy.
    import shutil
    shutil.copytree(BASE/'study',out/'study')
    rows=[];start=time.monotonic()
    for e in all_entries:
        p=Path(e['result']);row={k:e[k] for k in ['key','task','condition','kind']};rows.append(row)
        commands=[('checker',[sys.executable,'-B',str(BASE/'study/checker.py'),e['meta'],str(Path(e['out'])/'plan.json'),str(p/'check')]),
                  ('test',[sys.executable,'-B',str(BASE/'test_inputs.py'),'worker',str(out),e['key']])]
        row['commands']=commands
        for label,cmd in commands:
            remaining=1800-(time.monotonic()-start)
            if remaining<=0:row[label+'_exit']='total_cap';continue
            with (p/(label+'.log')).open('wb') as log:
                try:row[label+'_exit']=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,env=environment,timeout=min(180,remaining)).returncode
                except subprocess.TimeoutExpired:row[label+'_exit']='timeout'
        save(out/'STATUS.json',{'state':'running','pid':os.getpid(),'rows':rows})
        print('REPLAYED',e['key'],row['checker_exit'],row['test_exit'],flush=True)
    predictions={e['key']:read(out/'test_inputs'/e['key']/'predictions.json') if (out/'test_inputs'/e['key']/'predictions.json').exists() else None for e in all_entries}
    save(out/'predictions.json',predictions);save(out/'PREDICTION_FREEZE.json',{'sha256':sha(out/'predictions.json'),'time':time.time(),'prior_answer_exposure':True})
    # Scoring and comparison happen after all predictions are frozen.
    expected=read(BASE/'EXPECTED.json');count={c:{'opportunities':5,'available_proposals':0,'complete_demonstration_and_test_fits':0} for c in 'ABCD'}
    for e,row in zip(all_entries,rows):
        k=e['key'];p=Path(e['result']);ref=expected[e.get('source_key',k)]
        if row['checker_exit']!=0 or row['test_exit']!=0:row['agrees']=False;continue
        v=read(p/'check/verdict.json');vs={name:v[name] for name in ref['verdict']}
        pred=predictions[k]['slots'];truth=read(BASE/'answers'/(e['task']+'.json'))
        challenge=read(BASE/'runtime/data15b'/e['task']/'task.json')
        assert truth['train']==challenge['train']
        assert [x['input'] for x in truth['test']]==[x['input'] for x in challenge['test']]
        assert len(pred)==len(truth['test'])
        exact=all(a['prediction']==b['output'] for a,b in zip(pred,truth['test']))
        complete=v['all_seen_pass'] and all(x['pass'] for x in v['hidden'].values()) and exact
        agrees=(vs==ref['verdict'] and pred==ref['test_slots'])
        tracep=p/'check/trace.json'
        if tracep.exists():
            trace=read(tracep);sem={i:{a:d[a] for a in ['acts','guards','output','error']} for i,d in trace['demos'].items()}
            agrees=agrees and digest(sem)==ref['primitive_trace_sha256']
            if e['kind']=='factored':
                witnesses=[w for d in trace['demos'].values() for w in d['witnesses'] if w['def']=='u0001']
                row['effectful_saved_calls']=len(witnesses);agrees=agrees and len(witnesses)==9
        row.update(agrees=agrees,test_exact=exact,complete_fit=complete)
        if e['kind']=='original':
            count[e['condition']]['available_proposals']+=1;count[e['condition']]['complete_demonstration_and_test_fits']+=int(complete)
    # Direct invocation from the saved response, without factoring.
    positive=read(out/'k100f065378/check/trace.json')
    witnesses=[w for d in positive['demos'].values() for w in d['witnesses'] if w['def']=='u0001']
    assert len(witnesses)==9
    verify()
    result={'state':'completed','opportunities':20,'available_proposals':19,'reader_timeouts':1,'arms':count,
        'all_saved_outcomes_and_traces_reproduced':all(r['agrees'] for r in rows),
        'effectful_saved_calls':len(witnesses),
        'rows':rows,'elapsed_seconds':time.monotonic()-start,'source_hashes_unchanged':True,
        'scope':'Saved-program replay only; original readers are not rerun and no new task-solving performance is claimed'}
    save(out/'RESULT.json',result);save(out/'STATUS.json',{'state':'completed'})
    print(json.dumps({k:v for k,v in result.items() if k not in ['rows','expansion_checks']},indent=2))
    assert result['all_saved_outcomes_and_traces_reproduced']

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',required=True);a=p.parse_args();run(a.out)
