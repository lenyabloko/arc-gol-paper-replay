"""Postspecified test-input audit; freeze predictions before a separate answer-scoring invocation."""
import hashlib,json,os,subprocess,sys,time
from pathlib import Path
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.write_text(json.dumps(x,indent=2),encoding='utf-8')

def worker(root,key):
    root=Path(root);protocol=read(root/'PROTOCOL.json');entry=next(e for e in protocol['entries'] if e['key']==key)
    out=root/'test_inputs'/key;out.mkdir()
    meta=read(Path(entry['meta']));plan=read(Path(entry['out'])/'plan.json')
    sys.path.insert(0,str(root/'study'))
    import common as CM
    import checker as CHECK
    rt=CM.runtime_room(meta['task'],str(out))
    os.environ['STORE15']=meta['store_exec']
    GOL=CM.enter(rt);D=GOL.D
    import arcroom as AR
    for name in ('new','segment'):
        def forbidden(self,*args,name=name): raise D.Refused(name+' forbidden')
        setattr(D.GolScene,name,forbidden)
    oldsplit=D.GolScene.split
    def split(self,o,m,tick):
        if m==1:raise D.Refused('single pieces forbidden')
        return oldsplit(self,o,m,tick)
    D.GolScene.split=split
    try:
        P=GOL.program(meta['task'],dict(plan,task=meta['task']),traced=True)
        violations=CHECK.expanded_violations(P.expanded)
    except Exception as exc:
        P=None;violations=[type(exc).__name__+': '+str(exc)]
    slots=[]
    for name in AR.grid_names():
        if not name.startswith('t'):continue
        outputs=[];errors=[];mirrors=[]
        if violations:
            slots.append({'name':name,'prediction':None,'error':violations});continue
        for base in [1,1001]:
            try:
                G,H,W,bg=D.reading(name,meta['view']['abstraction'],meta['view']['background'],None)
                S=GOL.State(D.GolScene.of_graph(G,H,W,bg,[base]));R=GOL.TRun(P,GOL.FUEL*10,{})
                R.do(S,P.expanded);scene=S.sc['out']
                graph={}
                for handle,node in scene.key.items():
                    d=scene.G.graph.nodes[node];points=[tuple(map(int,p)) for p in d['nodes']]
                    cols=d['color'] if isinstance(d['color'],list) else [d['color']]*len(points)
                    graph[handle]=dict(zip(points,map(int,cols)))
                mirrors.append(graph==scene.mir);outputs.append(scene.render());errors.append(None)
            except Exception as exc:
                outputs.append(None);errors.append(type(exc).__name__+': '+str(exc)[:300]);mirrors.append(False)
        valid=all(mirrors) and not any(errors) and outputs[0]==outputs[1]
        slots.append({'name':name,'prediction':outputs[0] if valid else None,'errors':errors,
                      'node_numbering_invariant':outputs[0]==outputs[1],'final_graph_mirror_consistent':all(mirrors)})
    save(out/'predictions.json',{'key':key,'slots':slots})

def predict(root):
    root=Path(root);assert read(root/'STATUS.json')['state']=='completed'
    dest=root/'test_inputs';dest.mkdir(exist_ok=False)
    protocol=read(root/'PROTOCOL.json');entries=protocol['entries']
    commands={e['key']:[sys.executable,'-B',str(Path(__file__).resolve()),'worker',str(root),e['key']] for e in entries}
    plans={e['key']:sha(Path(e['out'])/'plan.json') for e in entries}
    save(dest/'PROTOCOL.json',{'phase':'postspecified after demonstration outcomes; all twenty unchanged proposals',
         'prior_answer_exposure':True,'new_reader_calls':0,'worker_seconds':120,'total_seconds':1800,
         'commands':commands,'plan_sha256':plans,'prediction_code_sha256':sha(Path(__file__)),
         'scoring_policy':'Public training task test inputs, same fixed views and definitions; static rejection, timeout or abstention incorrect. Verify all demonstrations and test input bytes before scoring.',
         'original_reader_protocol_sha256':sha(root/'PROTOCOL.json')})
    env=dict(os.environ,TRACE_R7=str(root/'runtime'),STUDY_REGISTRY='original',PYTHONDONTWRITEBYTECODE='1',PYTHONIOENCODING='utf-8')
    started=time.monotonic();rows=[]
    for e in entries:
        output=dest/e['key'];remaining=1800-(time.monotonic()-started)
        if remaining<=0:rc='total_cap'
        else:
            with (dest/(e['key']+'.log')).open('wb') as log:
                try:rc=subprocess.run(commands[e['key']],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=min(120,remaining)).returncode
                except subprocess.TimeoutExpired:rc='timeout'
        assert sha(Path(e['out'])/'plan.json')==plans[e['key']]
        slots=read(output/'predictions.json')['slots'] if rc==0 and (output/'predictions.json').exists() else [
            {'name':'t%d_in'%i,'prediction':None,'error':str(rc)} for i in range(len(read(root/'runtime/data15b'/e['task']/'task.json')['test']))]
        rows.append({'key':e['key'],'task':e['task'],'condition':e['condition'],'worker_exit':rc,'slots':slots})
        save(dest/'STATUS.json',{'state':'running','rows':rows});print('PREDICTED',e['key'],rc,flush=True)
    save(dest/'predictions.json',rows)
    save(dest/'PREDICTION_FREEZE.json',{'sha256':sha(dest/'predictions.json'),'time':time.time(),'answers_opened_this_audit':False,'prior_answer_exposure':True})
    save(dest/'STATUS.json',{'state':'completed','rows':rows})

def score(root):
    root=Path(root);dest=root/'test_inputs';freeze=read(dest/'PREDICTION_FREEZE.json')
    assert sha(dest/'predictions.json')==freeze['sha256']
    rows=read(dest/'predictions.json');source=Path('C:/Users/lenya/arc_local_runs/paper_cross_task_palette_revision_20261108/scoring')
    sources={r['task']:r for r in read(source/'RESULT.json')['rows']}
    scored=[]
    for row in rows:
        task=row['task'];file=source/(task+'.json')
        assert sha(file)==sources[task]['source_sha256']
        truth=read(file);challenge=read(root/'runtime/data15b'/task/'task.json')
        assert truth['train']==challenge['train']
        assert [t['input'] for t in truth['test']]==[t['input'] for t in challenge['test']]
        assert len(row['slots'])==len(truth['test'])
        exact=[s['prediction']==t['output'] for s,t in zip(row['slots'],truth['test'])]
        scored.append({k:row[k] for k in ['key','task','condition','worker_exit']} | {'exact':exact,'exact_task':all(exact),
                      'abstentions':sum(s['prediction'] is None for s in row['slots'])})
    arms={c:{'tasks':5,'test_inputs':sum(len(r['exact']) for r in scored if r['condition']==c),
             'exact_tasks':sum(r['exact_task'] for r in scored if r['condition']==c),
             'exact_inputs':sum(sum(r['exact']) for r in scored if r['condition']==c),
             'abstentions':sum(r['abstentions'] for r in scored if r['condition']==c)} for c in 'ABCD'}
    report={'scope':'Postspecified frozen-program verification on five exposed public-training tasks; no benchmark or independent-family claim',
            'prediction_sha256':freeze['sha256'],'challenge_mismatches':0,'source_files':sources,'arms':arms,'rows':scored}
    save(dest/'SCORE.json',report);print(json.dumps(arms,indent=2))

if __name__=='__main__':globals()[sys.argv[1]](*sys.argv[2:])
