TARGET-READER AND EXACT-FACTORING REPLAY SUPPLEMENT

Prepared locally; public release has not yet been approved.

This package contains all twenty saved proposals from the five-task crossed
observation/store pilot, including four native rejections. Three exact factored
versions reuse the unchanged downward action on one different task. It retains
the reader inputs and views, plans, public training task answers, the original
graph runtime, execution stores, expected outcomes and a replay runner.
No model-session reasoning logs, credentials, private competition payload,
protected evaluation tasks or new model calls are included.

With Python 3.12 and the requirements installed, from this directory run:
  python -B replay.py --out ../target_replay_results
Choose a new output directory outside this package. The runner checks every
member hash, executes all twenty original and three factored plans in separate
processes, freezes predictions before scoring, and compares primitive traces,
outputs and exact untraced compiler expansion. Limit: 180 seconds per process,
1800 seconds total. Package sources and stored knowledge must remain unchanged.

Expected original complete demonstration-and-test fits: A=4, B=3, C=4, D=4,
each among five proposals. No original proposal calls a saved action. The three
factored programs concern ONE target task; all remain correct, with nine
effectful saved calls per program across its three demonstrations. This checks
saved executable behavior; it does not rerun acquisition, measure retrieval
benefit, establish cumulative learning, or add independent task successes.

A=grids; B=grids+graphs; C=grids+store; D=grids+graphs+store. All use the same
mcccg8/corner_supported executor contract. Native source files and stores are
unchanged; only metadata file locations are relocated for replay. Answers were
already exposed to the study coordinator. Source task data: ARC-AGI-2 public
training, commit f3283f727488ad98fe575ea6a5ac981e4a188e49, Apache 2.0; see
ARC-AGI-2-LICENSE.txt. Preserve the inherited runtime MIT notice in LICENSE.
The package does not change existing licenses or license private solver data.
