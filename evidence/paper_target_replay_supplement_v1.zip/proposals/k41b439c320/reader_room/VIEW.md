# The view (mcccg8, canvas corner_supported) of each demonstration you see

Node numbers below are for reading only: a program must not contain them.

## Demonstration 1, input (view_1_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 1 | 1, 7, 1, 7 |
| 2 | 8 | 1 | 3, 2, 3, 2 |
| 3 | 8 | 1 | 6, 5, 6, 5 |
| 4 | 8 | 1 | 6, 9, 6, 9 |
| 5 | 8 | 1 | 8, 2, 8, 2 |

Relations: 1>2 above, right_of, same_colour, same_shape, same_size; 1>3 above, right_of, same_colour, same_shape, same_size; 1>4 above, left_of, same_colour, same_shape, same_size; 1>5 above, right_of, same_colour, same_shape, same_size; 2>1 below, left_of, same_colour, same_shape, same_size; 2>3 above, left_of, same_colour, same_shape, same_size; 2>4 above, left_of, same_colour, same_shape, same_size; 2>5 above, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 3>1 below, left_of, same_colour, same_shape, same_size; 3>2 below, right_of, same_colour, same_shape, same_size; 3>4 left_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_colour, same_shape, same_size; 3>5 above, right_of, same_colour, same_shape, same_size; 4>1 below, right_of, same_colour, same_shape, same_size; 4>2 below, right_of, same_colour, same_shape, same_size; 4>3 right_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_colour, same_shape, same_size; 4>5 above, right_of, same_colour, same_shape, same_size; 5>1 below, left_of, same_colour, same_shape, same_size; 5>2 below, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 5>3 below, left_of, same_colour, same_shape, same_size; 5>4 below, left_of, same_colour, same_shape, same_size; 4 touches_border

## Demonstration 1, output (view_1_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 1 | 1, 7, 1, 7 |
| 2 | 8 | 6 | 3, 2, 8, 2 |
| 3 | 8 | 5 | 6, 5, 6, 9 |

Relations: 1>2 above, right_of, same_colour, smaller; 1>3 above, col_overlap, centre_col_aligned, same_colour, smaller; 2>1 below, left_of, same_colour, larger; 2>3 left_of, row_overlap, same_colour, larger; 3>1 below, col_overlap, centre_col_aligned, same_colour, larger; 3>2 right_of, row_overlap, same_colour, smaller; 3 touches_border

## Demonstration 2, input (view_2_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 1 | 3, 1, 3, 1 |
| 2 | 8 | 1 | 3, 6, 3, 6 |
| 3 | 8 | 1 | 7, 4, 7, 4 |
| 4 | 8 | 1 | 9, 6, 9, 6 |

Relations: 1>2 left_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_colour, same_shape, same_size; 1>3 above, left_of, same_colour, same_shape, same_size; 1>4 above, left_of, same_colour, same_shape, same_size; 2>1 right_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_colour, same_shape, same_size; 2>3 above, right_of, same_colour, same_shape, same_size; 2>4 above, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 3>1 below, right_of, same_colour, same_shape, same_size; 3>2 below, left_of, same_colour, same_shape, same_size; 3>4 above, left_of, same_colour, same_shape, same_size; 4>1 below, right_of, same_colour, same_shape, same_size; 4>2 below, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 4>3 below, right_of, same_colour, same_shape, same_size; 4 touches_border

## Demonstration 2, output (view_2_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 12 | 3, 1, 9, 6 |
| 2 | 8 | 1 | 7, 4, 7, 4 |

Relations: 1>2 row_overlap, col_overlap, same_colour, larger; 2>1 row_overlap, col_overlap, same_colour, smaller; 1 touches_border
