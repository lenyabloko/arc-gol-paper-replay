# The view (mcccg8, canvas corner_supported) of each demonstration you see

Node numbers below are for reading only: a program must not contain them.

## Demonstration 1, input (view_1_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 5 | 1 | 1, 7, 1, 7 |
| 2 | 5 | 1 | 2, 3, 2, 3 |
| 3 | 5 | 1 | 5, 7, 5, 7 |
| 4 | 5 | 1 | 7, 3, 7, 3 |

Relations: 1>2 above, right_of, same_colour, same_shape, same_size; 1>3 above, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 1>4 above, right_of, same_colour, same_shape, same_size; 2>1 below, left_of, same_colour, same_shape, same_size; 2>3 above, left_of, same_colour, same_shape, same_size; 2>4 above, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 3>1 below, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 3>2 below, right_of, same_colour, same_shape, same_size; 3>4 above, right_of, same_colour, same_shape, same_size; 4>1 below, left_of, same_colour, same_shape, same_size; 4>2 below, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 4>3 below, left_of, same_colour, same_shape, same_size

## Demonstration 1, output (view_1_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 1,5 | 9 | 0, 6, 2, 8 |
| 2 | 1,5 | 9 | 1, 2, 3, 4 |
| 3 | 1,5 | 9 | 4, 6, 6, 8 |
| 4 | 1,5 | 9 | 6, 2, 8, 4 |

Relations: 1>2 right_of, row_overlap, same_colour, same_shape, same_size; 1>3 above, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 1>4 above, right_of, same_colour, same_shape, same_size; 2>1 left_of, row_overlap, same_colour, same_shape, same_size; 2>3 above, left_of, same_colour, same_shape, same_size; 2>4 above, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 3>1 below, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 3>2 below, right_of, same_colour, same_shape, same_size; 3>4 right_of, row_overlap, same_colour, same_shape, same_size; 4>1 below, left_of, same_colour, same_shape, same_size; 4>2 below, col_overlap, centre_col_aligned, left_aligned, right_aligned, same_colour, same_shape, same_size; 4>3 left_of, row_overlap, same_colour, same_shape, same_size; 1 touches_border; 3 touches_border; 4 touches_border

## Demonstration 2, input (view_2_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 5 | 1 | 1, 6, 1, 6 |
| 2 | 5 | 1 | 4, 3, 4, 3 |
| 3 | 5 | 1 | 7, 1, 7, 1 |

Relations: 1>2 above, right_of, same_colour, same_shape, same_size; 1>3 above, right_of, same_colour, same_shape, same_size; 2>1 below, left_of, same_colour, same_shape, same_size; 2>3 above, right_of, same_colour, same_shape, same_size; 3>1 below, left_of, same_colour, same_shape, same_size; 3>2 below, left_of, same_colour, same_shape, same_size

## Demonstration 2, output (view_2_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 1,5 | 27 | 0, 0, 8, 7 |

Relations: 1 touches_border
