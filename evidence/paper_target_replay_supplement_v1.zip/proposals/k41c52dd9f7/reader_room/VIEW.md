# The view (mcccg8, canvas corner_supported) of each demonstration you see

Node numbers below are for reading only: a program must not contain them.

## Demonstration 1, input (view_1_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 1 | 16 | 2, 18, 5, 23 |
| 2 | 8 | 16 | 6, 4, 9, 9 |
| 3 | 3 | 16 | 8, 24, 11, 29 |
| 4 | 6 | 16 | 10, 12, 13, 17 |

Relations: 1>2 above, right_of, same_shape, same_size; 1>3 above, left_of, same_shape, same_size; 1>4 above, right_of, same_shape, same_size; 2>1 below, left_of, same_shape, same_size; 2>3 left_of, row_overlap, same_shape, same_size; 2>4 above, left_of, same_shape, same_size; 3>1 below, right_of, same_shape, same_size; 3>2 right_of, row_overlap, same_shape, same_size; 3>4 right_of, row_overlap, same_shape, same_size; 4>1 below, left_of, same_shape, same_size; 4>2 below, right_of, same_shape, same_size; 4>3 left_of, row_overlap, same_shape, same_size; 3 touches_border; 4 touches_border

## Demonstration 1, output (view_1_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 16 | 6, 4, 9, 9 |
| 2 | 1,3,6 | 48 | 6, 12, 9, 29 |

Relations: 1>2 left_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, smaller; 2>1 right_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, larger; 2 touches_border

## Demonstration 2, input (view_2_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 16 | 1, 10, 5, 13 |
| 2 | 2 | 16 | 3, 3, 7, 6 |
| 3 | 4 | 16 | 7, 16, 11, 19 |

Relations: 1>2 right_of, row_overlap, same_shape, same_size; 1>3 above, left_of, same_shape, same_size; 2>1 left_of, row_overlap, same_shape, same_size; 2>3 left_of, row_overlap, same_shape, same_size; 3>1 below, right_of, same_shape, same_size; 3>2 right_of, row_overlap, same_shape, same_size

## Demonstration 2, output (view_2_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 2 | 16 | 1, 3, 5, 6 |
| 2 | 8 | 16 | 1, 10, 5, 13 |
| 3 | 4 | 16 | 1, 16, 5, 19 |

Relations: 1>2 left_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_shape, same_size; 1>3 left_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_shape, same_size; 2>1 right_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_shape, same_size; 2>3 left_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_shape, same_size; 3>1 right_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_shape, same_size; 3>2 right_of, row_overlap, centre_row_aligned, top_aligned, bottom_aligned, same_shape, same_size
