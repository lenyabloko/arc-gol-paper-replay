# The view (mcccg8, canvas corner_supported) of each demonstration you see

Node numbers below are for reading only: a program must not contain them.

## Demonstration 1, input (view_1_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 1 | 1 | 3, 3, 3, 3 |
| 2 | 1 | 1 | 6, 6, 6, 6 |

Relations: 1>2 above, left_of, same_colour, same_shape, same_size; 2>1 below, right_of, same_colour, same_shape, same_size

## Demonstration 1, output (view_1_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 1,2,3 | 40 | 0, 0, 8, 8 |

Relations: 1 touches_border

## Demonstration 2, input (view_2_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 1 | 1 | 1, 11, 1, 11 |
| 2 | 1 | 1 | 3, 2, 3, 2 |
| 3 | 1 | 1 | 6, 9, 6, 9 |
| 4 | 1 | 1 | 9, 5, 9, 5 |

Relations: 1>2 above, right_of, same_colour, same_shape, same_size; 1>3 above, right_of, same_colour, same_shape, same_size; 1>4 above, right_of, same_colour, same_shape, same_size; 2>1 below, left_of, same_colour, same_shape, same_size; 2>3 above, left_of, same_colour, same_shape, same_size; 2>4 above, left_of, same_colour, same_shape, same_size; 3>1 below, left_of, same_colour, same_shape, same_size; 3>2 below, right_of, same_colour, same_shape, same_size; 3>4 above, right_of, same_colour, same_shape, same_size; 4>1 below, left_of, same_colour, same_shape, same_size; 4>2 below, right_of, same_colour, same_shape, same_size; 4>3 below, left_of, same_colour, same_shape, same_size

## Demonstration 2, output (view_2_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 1,2,3 | 104 | 0, 0, 12, 12 |

Relations: 1 touches_border
