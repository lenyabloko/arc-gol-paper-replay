# Your task

You are a reader in a closed room: this directory. Read PROMPT.md, API.md and GOL_REFERENCE.md. Look at demos.png (each row: an input and its output). Write plan.json: a GOL program over ARCGraph nodes that turns every input into its output. Rules: no literal node numbers in the program (address nodes by iteration and guards); run no code; read only this directory; write only plan.json.

The program runs on the view named in API.md, built by the executor from each grid. You see 2 demonstration(s).
