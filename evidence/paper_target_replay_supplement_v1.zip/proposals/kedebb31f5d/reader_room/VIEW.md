# The view (mcccg8, canvas corner_supported) of each demonstration you see

Node numbers below are for reading only: a program must not contain them.

## Demonstration 1, input (view_1_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 0 | 62 | 0, 0, 11, 11 |
| 2 | 0 | 5 | 0, 6, 1, 9 |

Relations: 1>2 row_overlap, col_overlap, top_aligned, same_colour, larger; 2>1 row_overlap, col_overlap, top_aligned, same_colour, smaller; 1 touches_border; 2 touches_border

## Demonstration 1, output (view_1_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 0,3 | 62 | 0, 0, 11, 11 |
| 2 | 0 | 5 | 0, 6, 1, 9 |

Relations: 1>2 row_overlap, col_overlap, top_aligned, larger; 2>1 row_overlap, col_overlap, top_aligned, smaller; 1 touches_border; 2 touches_border

## Demonstration 2, input (view_2_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 2 | 0, 0, 1, 0 |
| 2 | 8 | 6 | 0, 2, 5, 3 |
| 3 | 8 | 59 | 0, 0, 11, 11 |
| 4 | 8 | 1 | 2, 11, 2, 11 |
| 5 | 8 | 1 | 11, 5, 11, 5 |

Relations: 1>2 left_of, row_overlap, top_aligned, same_colour, smaller; 1>3 row_overlap, col_overlap, top_aligned, left_aligned, same_colour, smaller; 1>4 above, left_of, same_colour, larger; 1>5 above, left_of, same_colour, larger; 2>1 right_of, row_overlap, top_aligned, same_colour, larger; 2>3 row_overlap, col_overlap, top_aligned, same_colour, smaller; 2>4 left_of, row_overlap, same_colour, larger; 2>5 above, left_of, same_colour, larger; 3>1 row_overlap, col_overlap, top_aligned, left_aligned, same_colour, larger; 3>2 row_overlap, col_overlap, top_aligned, same_colour, larger; 3>4 row_overlap, col_overlap, right_aligned, same_colour, larger; 3>5 row_overlap, col_overlap, bottom_aligned, same_colour, larger; 4>1 below, right_of, same_colour, smaller; 4>2 right_of, row_overlap, same_colour, smaller; 4>3 row_overlap, col_overlap, right_aligned, same_colour, smaller; 4>5 above, right_of, same_colour, same_shape, same_size; 5>1 below, right_of, same_colour, smaller; 5>2 below, right_of, same_colour, smaller; 5>3 row_overlap, col_overlap, bottom_aligned, same_colour, smaller; 5>4 below, left_of, same_colour, same_shape, same_size; 1 touches_border; 2 touches_border; 3 touches_border; 4 touches_border; 5 touches_border

## Demonstration 2, output (view_2_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 8 | 2 | 0, 0, 1, 0 |
| 2 | 3,8 | 76 | 0, 0, 11, 11 |
| 3 | 8 | 1 | 2, 11, 2, 11 |

Relations: 1>2 row_overlap, col_overlap, top_aligned, left_aligned, smaller; 1>3 above, left_of, same_colour, larger; 2>1 row_overlap, col_overlap, top_aligned, left_aligned, larger; 2>3 row_overlap, col_overlap, right_aligned, larger; 3>1 below, right_of, same_colour, smaller; 3>2 row_overlap, col_overlap, right_aligned, smaller; 1 touches_border; 2 touches_border; 3 touches_border
