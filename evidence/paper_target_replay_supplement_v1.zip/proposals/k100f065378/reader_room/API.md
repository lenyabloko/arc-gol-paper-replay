# The executable interface (identical in every condition)

- **Language:** your program is GOL, as described in `GOL_REFERENCE.md`. It runs on ARCGraph nodes. The executor builds them from each grid under the study's fixed view, which is the same for every reader.
- **Addressing nodes:** iterate with `first`, `next` and `last`, and choose nodes with guards: attributes, sizes, colours, and the relation tests in `GOL_REFERENCE.md`.
- **Forbidden:** a literal node number anywhere a node is expected. Node numbers depend on the grid, so a program that names one is rejected before it runs.
- **Forbidden operations:** `(split o 1)` (single pieces), `(new k)`, and any operation on the whole picture. A new node comes only from an existing node.
- **Checker:** one final proposal, no execution access, no feedback and no retries.
- **Output:** write `plan.json` as `{"defs": [...], "main": TERM}` (see `GOL_REFERENCE.md`, "Translation format"). Add an optional `"rule"` list: plain sentences, with no numbers or coordinates.

## Frozen object extraction (identical in every condition)

The view is `mcccg8` with background `corner_supported`. Select the most frequent colour among the distinct corner cells as the canvas colour; ties use the lowest colour number. Remove canvas-colour cells, then join all remaining cells connected by an edge or corner (eight neighbours), irrespective of colour. Each connected component is one object; its per-cell colours and positions are preserved. The output initially copies the input. Object handles are temporary: iterate and select with guards, never literal handles.
