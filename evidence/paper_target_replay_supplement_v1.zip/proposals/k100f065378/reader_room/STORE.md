# The store

Callable by name in your program.

- `u0001` (act; params obj): `(while (< (bottom out obj) (- (H out) 1)) (extend obj 2))`
- `u0002` (act; params obj, steps): `(seq (set remaining steps) (while (< 0 remaining) (seq (move obj 4) (set remaining (- remaining 1)))) (extend obj 4))`
