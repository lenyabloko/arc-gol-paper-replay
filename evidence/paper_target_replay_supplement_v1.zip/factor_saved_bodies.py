"""Retrospective exact-subtree factorization; no new definition or reader call."""
import hashlib,json,sys,time
from pathlib import Path

SOURCE=Path('C:/Users/lenya/arc_local_runs/paper_target_reader_20261108')
ROOT=Path('C:/Users/lenya/arc_local_runs/paper_target_body_factorization_20261108')
read=lambda p:json.loads(p.read_text(encoding='utf-8'))
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,x):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2),encoding='utf-8')

def match(pattern,term,params,bindings):
    if isinstance(pattern,str) and pattern in params:
        if pattern in bindings:return bindings[pattern]==term
        bindings[pattern]=term;return True
    if isinstance(pattern,list):
        return isinstance(term,list) and len(pattern)==len(term) and all(match(a,b,params,bindings) for a,b in zip(pattern,term))
    return type(pattern)==type(term) and pattern==term

def main():
    ROOT.mkdir(exist_ok=False)
    proto=read(SOURCE/'PROTOCOL.json');store=read(SOURCE/'store_retained/defs.json')
    assert len(proto['entries'])==20 and len(store)==2
    freeze={'classification':'Retrospective diagnostic prompted by inspecting generated programs; not preregistered reader outcome or a new learning experiment',
            'opportunities':20,'source_protocol_sha256':sha(SOURCE/'PROTOCOL.json'),
            'store_sha256':sha(SOURCE/'store_retained/defs.json'),
            'plans':{e['key']:sha(Path(e['out'])/'plan.json') for e in proto['entries']},
            'matcher_sha256':sha(Path(__file__)),
            'method':'Compile original program; top-down exact subtree matching of each stored body under consistent formal-parameter substitution only. Free registers remain literal. Recompile the factored term and require exact expanded-tree equality.',
            'no_normalizations':'No algebraic simplification, commutativity, loop rewriting, register renaming, new parameter, new primitive or new definition',
            'scope':'All twenty proposals retained, including native rejections. Original source/answers/store unchanged. Refactored terms are isolated analysis artifacts and cannot replace original reader outcomes.',
            'limits':{'static_wall_seconds':120,'matched_native_replay_per_process_seconds':180},
            'production_wake_activation':False,'new_acquisition':False,'started':time.time()}
    save(ROOT/'PROTOCOL.json',freeze)
    sys.path.insert(0,str(SOURCE/'runtime/room15/grain'))
    import grain1 as G
    patterns=[(d,G.parse(d['body'])) for d in store]
    rows=[]
    started=time.monotonic()
    for entry in proto['entries']:
        assert time.monotonic()-started<120
        key=entry['key'];plan=read(Path(entry['out'])/'plan.json')
        assert sha(Path(entry['out'])/'plan.json')==freeze['plans'][key]
        verdict=read(Path(entry['out'])/'check/verdict.json')
        row={k:entry[k] for k in ['key','task','condition']}
        row['matches']=[]
        if verdict['static_violations']:
            row.update(status='original_native_rejection',reasons=verdict['static_violations']);rows.append(row);continue
        if plan.get('leaves'):
            row.update(status='unsupported_leaf_declaration');rows.append(row);continue
        assert not {d['name'] for d in plan.get('defs',[])} & {d['name'] for d in store}
        definition_list=(store if entry['condition'] in 'CD' else [])+plan.get('defs',[])
        original=G.Program({'task':entry['task'],'basis':'obj1','abstraction':'nbccg',
                            'bg':plan.get('bg','modal'),'defs':definition_list,'leaves':[],'main':plan['main']})
        def rewrite(term,path=()):
            for definition,pattern in patterns:
                bindings={}
                if match(pattern,term,set(definition['params']),bindings):
                    assert set(bindings)==set(definition['params'])
                    call=[definition['name']]+[bindings[p] for p in definition['params']]
                    row['matches'].append({'path':list(path),'definition':definition['name'],'bindings':bindings,
                        'original_subtree':term,'call':call,'original_operator_nodes':G._nodes(term),'call_operator_nodes':G._nodes(call)})
                    return call
            return [rewrite(x,path+(i,)) for i,x in enumerate(term)] if isinstance(term,list) else term
        term=rewrite(original.expanded)
        factored=G.Program({'task':entry['task'],'basis':'obj1','abstraction':'nbccg',
                           'bg':plan.get('bg','modal'),'defs':store,'leaves':[],'main':term})
        assert factored.expanded==original.expanded
        row.update(status='factored' if row['matches'] else 'no_exact_subtree',expanded_operator_nodes=G._nodes(original.expanded),
                   compact_operator_nodes=G._nodes(term),exact_expansion_equality=True,
                   expanded_tree_sha256=hashlib.sha256(json.dumps(original.expanded,sort_keys=True).encode()).hexdigest())
        if row['matches']:
            save(ROOT/'proposals'/key/'plan.json',{'defs':[],'main':G.unparse(term)})
            save(ROOT/'proposals'/key/'expanded_reference.json',original.expanded)
        rows.append(row)
    result={'classification':freeze['classification'],'rows':rows,'all_opportunities':len(rows),
            'compilable':sum(r['status']!='original_native_rejection' for r in rows),
            'matched_proposals':sum(bool(r['matches']) for r in rows),
            'matched_tasks':sorted({r['task'] for r in rows if r['matches']}),
            'static_occurrences':sum(len(r['matches']) for r in rows),
            'store_unchanged':sha(SOURCE/'store_retained/defs.json')==freeze['store_sha256'],
            'interpretation':'An exact structural overlap can be factored into an existing definition without changing expanded control. It does not establish reader use of the store, reduced acquisition/search cost, or successful learning of applicability.'}
    assert result['store_unchanged']
    save(ROOT/'STATIC_RESULT.json',result)
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))

if __name__=='__main__':main()
