"""Check frozen evidence and recompute reported counts; no solver or LLM calls.

Run with Python 3.10 or newer: python verify.py
This audits saved observations. It does not independently reproduce an LLM
reading, primitive semantics, or the timing measurements themselves.
"""
from pathlib import Path
import hashlib
import json
import math
import re

ROOT = Path(__file__).resolve().parent


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def read(path):
    return json.loads(path.read_text(encoding="utf-8"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def close(a, b):
    return math.isclose(a, b, rel_tol=1e-10, abs_tol=1e-7)


def main():
    manifest = read(ROOT / "MANIFEST.json")
    for name, sha in manifest.items():
        require(digest(ROOT / name) == sha, "Checksum mismatch: " + name)

    matched = read(ROOT / "matched_interface/FINAL_RESULTS.json")
    counts = dict(readings=0, full_fits=0, store_enabled=0, references=0)
    for row in matched["rows"]:
        case = ROOT / "matched_interface/results" / row["key"]
        require(digest(case / "plan.json") == row["plan_sha256"], "Changed reader plan")
        verdict_path = case / "check_complete_runtime/verdict.json"
        require(digest(verdict_path) == row["verdict_sha256"], "Changed verdict")
        verdict = read(verdict_path)
        seen = sum(v["pass"] for v in verdict["seen"].values())
        hidden = sum(v["pass"] for v in verdict["hidden"].values())
        require((seen, hidden) == (row["shown_exact"], row["withheld_exact"]), "Reader counts disagree")
        full = seen == row["shown_total"] and hidden == row["withheld_total"]
        require(full == row["all_demonstrations_exact"], "Reader fit disagrees")
        names = sorted(set(re.findall(r"\bu\d+\b", read(case / "plan.json")["main"])))
        require(names == sorted(row["saved_names_referenced"]), "Saved-name references disagree")
        counts["readings"] += 1
        counts["full_fits"] += full
        if row["condition"] in ("C", "D"):
            counts["store_enabled"] += 1
            counts["references"] += bool(names)
    require(counts == dict(readings=8, full_fits=7, store_enabled=4, references=3), "Matched pilot summary differs")

    population = read(ROOT / "cost/source/POPULATION.json")["selected"]
    expected_names = {r["task"] + "_" + arm for r in population for arm in ("empty", "retained")}
    timing = []
    for folder in sorted((ROOT / "cost").glob("repeat_*")):
        summary = read(folder / "SUMMARY.json")
        require(set(summary["comparisons"]) == expected_names, "Incomplete cost population")
        total = {a: dict(cpu_seconds=0.0, wall_seconds=0.0, demonstration_executions=0, exact=0, errors=0)
                 for a in ("baseline", "filtered")}
        n = pruned = first = 0
        for name in sorted(expected_names):
            original_path = ROOT / "cost/source/results" / name / "CANDIDATES.jsonl"
            paired_path = folder / "results" / name / "PAIRED.jsonl"
            require(digest(original_path) == summary["evidence"][name]["source_sha256"], "Changed candidate log")
            require(digest(paired_path) == summary["evidence"][name]["paired_sha256"], "Changed paired log")
            original = [json.loads(s) for s in original_path.read_text().splitlines()]
            paired = [json.loads(s) for s in paired_path.read_text().splitlines()]
            require(len(original) == len(paired), "Incomplete paired replay")
            local = {a: {k: 0 for k in total[a]} for a in total}
            local_pruned = 0
            for old, pair in zip(original, paired):
                require((old["index"], old["depth"]) == (pair["index"], pair["depth"]), "Candidate order differs")
                baseline, filtered = pair["outcomes"]["baseline"], pair["outcomes"]["filtered"]
                signature = {k: old[k] for k in ("exact", "pixel_error", "error") if k in old}
                require(baseline == signature, "Baseline differs from frozen search")
                if filtered.get("pruned"):
                    require(old["depth"] == 2 and not baseline["exact"], "Unsafe exclusion")
                    require(bool(pair["witness"]["missing_colours"]), "Missing exclusion witness")
                    require(pair["measurements"]["filtered"]["demonstration_executions"] == 0, "Excluded program executed")
                    local_pruned += 1
                else:
                    require(baseline == filtered, "Non-excluded outcomes differ")
                first += old["depth"] == 1
                for arm in total:
                    for key, value in pair["measurements"][arm].items():
                        local[arm][key] += value
            recorded = summary["comparisons"][name]
            require(len(paired) == recorded["candidates"] and local_pruned == recorded["pruned"], "Schedule counts disagree")
            for arm in total:
                for key, value in local[arm].items():
                    require(close(value, recorded["metrics"][arm][key]), "Schedule metric disagrees")
                    total[arm][key] += value
            n += len(paired)
            pruned += local_pruned
        require((n, pruned, first) == (29289, 14798, 1062), "Aggregate coverage differs")
        for arm in total:
            for key, value in total[arm].items():
                require(close(value, summary["totals"][arm][key]), "Aggregate metric disagrees")
        ratio = total["filtered"]["cpu_seconds"] / total["baseline"]["cpu_seconds"]
        require(close(ratio, summary["cpu_ratio"]), "Cost ratio disagrees")
        timing.append(dict(repetition=folder.name, candidates=n, excluded=pruned,
                           cpu_ratio=ratio, cpu_seconds={a: total[a]["cpu_seconds"] for a in total}))

    family = read(ROOT / "support/family_discriminability_20261108/RESULT.json")["rows"]
    for row in family:
        if "per_case" in row:
            require(len(row["per_case"]) == row["cases"], "Family case population differs")
            require(sum(v["pass"] for v in row["per_case"].values()) == row["exact"], "Family per-case counts disagree")
    family_counts = {r["program"]: r["exact"] for r in family}
    require(family_counts["REF_reader_program"] == family_counts["REF_stored_unit_program"] == 32, "Family count differs")
    require(family_counts["W1_no_split_readerA"] == 23 and family_counts["W5_R2_term_width_bound"] == 27, "Family controls differ")
    portability = read(ROOT / "support/external_consumer_20261108/RESULT.json")
    require(sum(r["external_exact"] for r in portability["rows"]) == 8, "Control portability count differs")
    require(all(not r["errors"] for r in portability["rows"]), "Recorded portability error")
    external = ROOT / "support/external_consumer_20261108"
    expected = read(external / "EXPECTED.json")["cases"]
    for row in portability["rows"]:
        task = row["task"]
        native, native_repeat, other, other_repeat = [
            read(external / "traces" / f"{task}_{backend}_{repeat}" / "PREDICTIONS.json")
            for backend in ("native", "external") for repeat in (1, 2)]
        require(native == native_repeat and other == other_repeat, "Fresh-process trace differs")
        require(native["rows"] == other["rows"] and native["expanded"] == other["expanded"], "Interpreter traces differ")
        exact = sum(r["output"] == expected[task][r["case"]]["output"] for r in other["rows"] if r["handle_start"] == 1)
        require(exact == row["external_exact"], "External output count disagrees")
    print(json.dumps(dict(verified_files=len(manifest), matched_interface=counts,
                          family_recorded_counts=family_counts, external_recorded_exact=8,
                          timing_recomputations=timing,
                          scope="Saved-evidence audit; no new execution, learning or timing measurement"), indent=2))


if __name__ == "__main__":
    main()
