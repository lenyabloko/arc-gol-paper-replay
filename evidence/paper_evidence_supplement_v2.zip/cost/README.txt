Paired effect-filter replay, 8 November 2026

Question: can a conservative effect contract avoid terminal candidate execution
without changing exact-fit decisions on the frozen palette-revision schedules?
This is retrospective development evidence on five exposed public-training tasks,
not another search, a learned-applicability experiment or a new transfer score.

Every recorded candidate is replayed in the original order. The baseline parses,
expands and executes it on the demonstrations. The screened condition first
overapproximates the colours its expanded operations can introduce. A terminal
depth-two candidate is rejected only if a demonstration requires a colour absent
from its initial objects/background and all possible introduced colours. Unknown
operations and nonliteral colour expressions disable rejection. All first-stage
candidates execute because their states are needed for beam construction.

Both conditions use identical pinned native runtime, graph views and store.
They start from fresh graph copies; baseline-first and screened-first order
alternate by candidate index. CPU and wall timing include parsing, expansion,
screening, copying, execution and rendering, but exclude shared perception setup,
candidate generation, ranking and log writing. Two workers run concurrently.
The per-worker cap was fixed at 360 seconds; all ten workers completed normally.

Results:
  Five tasks, ten frozen schedules, 29,289 candidate checks.
  14,798 terminal candidates excluded; all 1,062 first-stage checks executed.
  No lost exact fit, no non-excluded divergence, no frozen-baseline disagreement.
  Demonstration executions: 81,152 baseline, 40,289 screened.
  Summed process CPU seconds: 783.546875 baseline, 491.984375 screened.
  CPU ratio: 0.627894, approximately 37% less measured checking CPU time.
  Summed timed wall seconds: 821.320567 baseline, 512.412637 screened.
  No additional task solved, no changed prediction and no changed stored body.

The two recorded exact candidate fits represent the same successful task in the
empty and retained arms, not two independent tasks. Supplied controls additionally
exercise successful terminal composition, conservative fallback on a computed
colour, a missing-colour exclusion, and a colour-compatible but wrong program.
All four controls behave as declared; they are not learned solutions.

The machine is an Intel Core i7-8550U (four cores, eight logical processors),
Windows 11, Python 3.12. This is one paired interleaved pass, not a timing study
with uncertainty estimates. Process CPU is the primary timing measurement; other
local activity was not excluded. Do not interpret the result as end-to-end search
speedup, a lattice benefit, retained-knowledge advantage or unseen-task accuracy.

Run from the repository root with the offline_replay dependencies installed:
  python experiments/paper_gol_examples/cross_task_search_20261108/replay_effect_filter.py --source <complete-palette-revision-run> --out <new-directory>
  python experiments/paper_gol_examples/cross_task_search_20261108/effect_filter_controls.py --source <complete-palette-revision-run> --out <new-control-directory>
  python experiments/paper_gol_examples/cross_task_search_20261108/summarize_effect_filter.py --run <new-directory> --source <complete-palette-revision-run>

The source is the complete original local palette-revision run, including its
candidate logs, frozen runtime rooms and stores, not the compact source evidence.
All source hashes remain unchanged. No LLM or network calls are made. The complete
paired logs are bound by EXTERNAL_PAIRED_LOGS.json, retained on C: and backed up
to E:. This folder contains compact protocols, outcomes, controls and summaries.
