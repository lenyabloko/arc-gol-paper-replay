Native-body caller search, 8 November 2026

Question: can a bounded deterministic search form a caller of an acquired GOL
body without translating that body into a one-step effect summary?

Run from the repository root with the offline replay dependencies:
  python experiments/paper_gol_examples/body_composition_20261108/run.py --out <new-search-directory>
  python experiments/paper_gol_examples/body_composition_20261108/validate.py --search <search-directory> --out <new-validation-directory>

The runner verifies the frozen runtime and uses the original registry. It never
changes definitions or solver semantics. Search receives the first two source
demonstrations and the existing two-definition store. Both tasks and their
solutions were previously exposed to the experimenter. The third demonstration
was already used admitting the store, so it is source support, not an independent
hold-out. No public test answer is scored in this experiment.

The same 119 single-phase candidates are available for both tasks: supplied
input/output-object traversal, primitive actions, and calls to saved definitions
with constants or object/scene attributes. If none fits, search combines up to
two phases, retaining at most 32 distinct first-stage states ranked by pixel
error. Source and grammar are frozen before execution. Budgets are 3,000
candidate programs, 600 seconds per search, and 100,000 interpreter steps per
demonstration. Every rejected candidate remains in the evidence. This is bounded
caller synthesis with supplied control scaffolding, not whole-language search.

Results:
- Diagonal: candidate 49 calls u0002 with the node's size. All 3 source outputs
  match; native tracing records 3 saved-action calls.
- Downward: candidate 125 repeats a primitive extension twice, without calling
  either saved action. All 3 source outputs match, but only 2 of the 32 fixed
  synthetic family outputs match. No program was repaired or reselected.
- Fresh-process validation repeated each source group and the family group:
  semantic traces agree, graph/mirror mismatches are zero, and source/store
  checksums are unchanged. Repeats are not additional task samples.

The diagonal caller has the same token structure as the earlier reader-generated
caller, but no reader program was an input to search. Knowledge of that example
influenced the choice of this implementation diagnostic; this is not a blind
discovery claim. There is no matched empty-store comparison, population transfer
estimate, applicability-learning result or production admission. The first-fit
downward result demonstrates why search fit cannot substitute for generalization.
