Paper evidence supplement, version 2 � prepared for review

This is a companion to the limited public ARC/GOL replay package. It collects
records supporting the manuscript's principal findings, without publishing the
private project, competition solver, cloud outbox, chat archive, or sealed data.
It is not a new learning experiment and does not claim a complete learning loop.

Contents
- original/: the previously prepared supplement, including all six original
  construction readings and both acquisition rooms on two exposed training tasks.
- matched_interface/: all eight source-task caller proposals, final checker
  verdicts and the recorded audit corrections. Both successful and rejected
  proposals are included. The proposals are not new task-separated readings.
- support/: complete recorded synthetic-family comparison and control-interpreter
  portability records, with protocols and unchanged action/state traces. The
  verifier compares the saved traces and public expected outputs; it does not
  rerun their semantics. The existing public package replays the two
  acquired definitions, their support and the same 32-scene family.
- native_caller_search/: the bounded source-task caller-search protocol and results.
- cost/: every original candidate and paired cost record for the five fixed
  public-training tasks. Repetitions replay identical schedules; they do not add
  independent tasks. Candidate logs include errors and unsuccessful outcomes.

Audit command (Python 3.10 or newer; standard library only)
  python verify.py

The command checks package hashes, reconstructs the matched-reader counts from
unchanged plans and verdicts, and recomputes checking costs from all paired logs.
It checks each baseline signature against the original search record, verifies
that no exact fit was excluded, and compares all non-excluded paired outcomes.
It reports the original pass and both predeclared repetitions. It does not call an LLM, execute GOL,
remeasure speed, or independently validate graph primitives or the colour proof.
The original public runtime package remains the source of executable replay.

Evidence fidelity
SOURCE_MANIFEST.json records source and packaged hashes. JSON views omit only
machine-specific launch-command fields, with every omitted field listed. Outcome
fields are retained; byte-copied plans, verdicts and candidate logs are unchanged.
The original supplement's README describes its earlier scope and remains intact.
MANIFEST.json hashes every packaged file except itself. Hashes establish byte
identity, not the scientific validity of the original experiment.

Data and scope
The reader material concerns two previously exposed public ARC-AGI-2 training
tasks. The cost study concerns the same five public-training tasks selected in
the recorded search protocol, excluding the acquisition tasks. The palette
revision and cost replay are retrospective development diagnostics. They cannot
establish independent test accuracy, general transfer, learned applicability or
a lattice advantage. No protected evaluation population, sealed readings, raw
model-session logs, or credentials are included.

Release status
Prepared locally; not published. This evidence collection exceeds the original
95-file public replay approval. Review its manifest and archive before release.
