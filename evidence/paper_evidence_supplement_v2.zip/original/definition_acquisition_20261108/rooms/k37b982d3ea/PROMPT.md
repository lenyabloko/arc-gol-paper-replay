# Your task

You are a reader in a closed room: this directory. Read PROMPT.md, API.md and GOL_REFERENCE.md, VIEW.md and the view pictures. Look at demos.png (each row: an input and its output). Write plan.json: a GOL program over ARCGraph nodes that turns every input into its output. Rules: no literal node numbers in the program (address nodes by iteration and guards); run no code; read only this directory; write only plan.json.

The program runs on the view named in API.md, built by the executor from each grid. You see 2 demonstration(s).

This is a separate reusable-definition acquisition condition. Express the inferred rule using one or more parameterized GOL definitions in the defs array, called by main. Factor a meaningful object-level action or relation with explicit parameters, not the entire task solution in a zero-argument wrapper. Use only the supplied language syntax and operations. Include a brief domain interpretation and applicability assumptions in a separate explanation field. Do not supply unused definitions. You have one proposal and no execution feedback. No prior solutions or generated programs are supplied.
