# The executable interface (identical in every condition)

- **Language:** your program is GOL, as described in `GOL_REFERENCE.md`. It runs on ARCGraph nodes. The executor builds them from each grid under the study's fixed view, which is the same for every reader.
- **Addressing nodes:** iterate with `first`, `next` and `last`, and choose nodes with guards: attributes, sizes, colours, and the relation tests in `GOL_REFERENCE.md`.
- **Forbidden:** a literal node number anywhere a node is expected. Node numbers depend on the grid, so a program that names one is rejected before it runs.
- **Forbidden operations:** `(split o 1)` (single pieces), `(new k)`, and any operation on the whole picture. A new node comes only from an existing node.
- **Checker:** it runs your program on every demonstration you see.
  - It reports pass or fail for each one.
  - For the first failure, it gives a picture of the input, the expected output and your output.
  - It reports no node data, and you have at most 4 checks.
- **Output:** write `plan.json` as `{"defs": [...], "main": TERM}` (see `GOL_REFERENCE.md`, "Translation format"). Add an optional `"rule"` list: plain sentences, with no numbers or coordinates.
