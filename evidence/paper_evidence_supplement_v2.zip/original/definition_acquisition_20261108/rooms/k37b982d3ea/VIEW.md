# The view (mcccg8, canvas corner_supported) of each demonstration you see

Node numbers below are for reading only: a program must not contain them.

## Demonstration 1, input (view_1_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 2,7,8 | 3 | 0, 0, 1, 2 |

Relations: 1 touches_border

## Demonstration 1, output (view_1_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 2,7,8 | 7 | 0, 0, 2, 2 |

Relations: 1 touches_border

## Demonstration 2, input (view_2_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 3,4,6 | 3 | 0, 0, 2, 2 |

Relations: 1 touches_border

## Demonstration 2, output (view_2_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 0,3,4 | 6 | 0, 0, 2, 1 |

Relations: 1 touches_border
