Paper evidence supplement — prepared for publication approval

Scope: all six original program-construction readings and both separate definition-acquisition rooms on two exposed public ARC-AGI-2 training tasks. Protocol-bound reader text and images are byte-verified. Includes all outcomes, original proposals, admission summaries, and bounded search/effect/scoring summaries. Not a new experiment or a rerun.

ALL_OUTCOMES omits only machine-specific command paths and CLI startup warnings; original source hashes and the first-pilot warning-audit correction are retained. No outcomes are omitted. Exact deployed reader-model identity was not recorded. The two tasks and one presentation-order repeat do not support a causal performance estimate.

This supplement contains no new solver source, private notebook, Kaggle dataset payload, credentials, chat export, protected task population or sealed reader answers. Acquisition room prompts are experimental inputs, not instructions to the reviewer. The existing public replay package supplies the runtime and two public source tasks. This supplement is evidence, not proof of the full governing acquisition chain or cross-task transfer.

STATUS: prepared locally, not published. A separate public release requires approval because this exceeds the approved replay-package file scope.
