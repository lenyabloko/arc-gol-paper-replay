# The view (nbccg8, canvas modal_color) of each demonstration you see

Node numbers below are for reading only: a program must not contain them.

## Demonstration 1, input (view_1_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 2 | 2 | 13, 1, 14, 2 |

Relations: 

## Demonstration 1, output (view_1_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 2 | 3 | 10, 3, 12, 5 |

Relations: 

## Demonstration 2, input (view_2_in.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 2 | 1 | 15, 0, 15, 0 |

Relations: 1 touches_border

## Demonstration 2, output (view_2_out.png)

| node | colours | size | box (top, left, bottom, right) |
|---|---|---|---|
| 1 | 2 | 2 | 13, 1, 14, 2 |

Relations: 
